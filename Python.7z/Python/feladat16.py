import turtle       


a = turtle.Screen()
a.bgcolor("green")
a.title("Negyzet")


Eszti = turtle.Turtle()
print(type(Eszti))


a.mainloop() 