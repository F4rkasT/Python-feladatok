a = int(input("Évek száma:"))

FV = 10000 * (1 + 0.08/12)**(12*a)
print(FV)