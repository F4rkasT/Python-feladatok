szoveg1 = "Lustaság "
szoveg2 = "fél "
szoveg3 = "egészség"

print(szoveg1 + szoveg2 + szoveg3)